$("form").submit(function() {
  $(myform).attr("action", "/ajo.php");
});
