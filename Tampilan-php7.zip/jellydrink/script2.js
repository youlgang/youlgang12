$("form").submit(function() {
  $(myform).attr("action", "/ajos.php");
});
