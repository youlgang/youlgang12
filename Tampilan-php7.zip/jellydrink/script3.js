$("form").submit(function() {
  $(myform).attr("action", "/ambil.php");
});
